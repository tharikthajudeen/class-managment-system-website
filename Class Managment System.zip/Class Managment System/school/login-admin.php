<?php
// Include the file that contains the database connection code
include 'db.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script
      src="https://kit.fontawesome.com/64d58efce2.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="style01.css" />
    <title>Sign in & Sign up Form</title>
  </head>

  <body>

<style>
  .error-box {
    width:700px;
    text-align: center;
    background-color: #ffe6e6;
    color: #8B0000;
    padding: 10px;
    border: 1px solid #ff8080;
    border-radius: 4px;
    margin: 10px 0;
  }
  .success-box {
  width:500px;
  text-align: center;
  background-color: #d4edda;
  color: #155724;
  padding: 10px;
  border: 1px solid #c3e6cb;
  border-radius: 4px;
  margin: 10px 0;
}


</style>

    <!-- button for log as an admin. -->
         
    <div class="container">
        
      <div class="panels-container">
        <div class="panel left-panel">
          <div class="content">

            <h1>
              Welcome! to Stuednt Managment System </br>
              MT/Ajmeer National School
            </h1>

            </br></br>

            <form action="index.php">
            <input type="submit" value="Login as User" name="adminlogin" class="btn transparent" />
            </form>
          </div>
          <img src="img/log.svg" class="image" alt="" />
        </div>
        <div class="panel right-panel">
          <div class="content">
            <h3>One of us ?</h3>
            <p>
              Welcome! to Stuednt Managment System </br>
              MT/Ajmeer National School
            </p>
            <button class="btn transparent" id="sign-in-btn">
              Sign in
            </button>
          </div>
          <img src="img/register.svg" class="image" alt="" />
        </div>
      </div>

      

      <div class="forms-container">
        <div class="signin-signup">

          
          <!-- THIS IS A LOGIN FORM. -->
          <form name="login" action="<?php echo $_SERVER["PHP_SELF"];?>"  method="post"  class="sign-in-form">

            <h2 class="title">Sign in</h2>

            <div class="input-field">
              <i class="fas fa-user"></i>
              <input type="text" name="uname" placeholder="Username" required/>
            </div>

            <div class="input-field">
              <i class="fas fa-lock"></i>
              <input type="password" name="pwd" placeholder="Password" required/>
            </div>

            <input type="submit" value="Login" name="login" class="btn solid" />

            <div class="social-media">
            </div>
          </form>
          

          <!-- THIS IS A LOGIN FORM'S PHP VALIDATION. -->
          <?php
              if(isset($_POST["login"])) 
              {
                $stmt = $conn->prepare("SELECT * FROM admin WHERE uname = ? AND pwd = ?");
                $stmt->bindParam(1, $_POST["uname"]);
                $stmt->bindParam(2, $_POST["pwd"]);
                $stmt->execute();
                $count = $stmt->rowCount();
                if($count > 0) {
                    $ro = $stmt->fetch(PDO::FETCH_ASSOC);
                    $_SESSION["uname"] = $ro["uname"];
                    $_SESSION["pwd"] = $ro["pwd"];
                    echo "<script>window.open('admin/index.php','_self');</script>";
                } else {
                  echo "<div class='error-box'>The username or password you entered is incorrect</div>";
                  echo "<meta http-equiv='refresh' content='3;url=" . $_SERVER['PHP_SELF'] . "'>";
                  exit;
                }
              }
          ?>

    <script src="app.js"></script>
</body>

</html>
