 <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="dlabnav">
            <div class="dlabnav-scroll">
                <ul class="metismenu" id="menu">
                    <li class="nav-label first">Main Menu</li>

                    <li><a class="has-arrow" href="index.php" aria-expanded="false">
                            <i class="la la-home"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                    </li>

					<li><a class="ai-icon" href="event-management.php" aria-expanded="false">
							<i class="la la-calendar"></i>
							<span class="nav-text">Event Management</span>
						</a>
                    </li>
					
					<li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
							<i class="la la-users"></i>
							<span class="nav-text">Students</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="all-students.php">All Students</a></li>
                            <li><a href="add-student.php">Add Students</a></li>
                            <li><a href="edit-student.php">Edit Students</a></li>
                            
                        </ul>
                    </li>
					
					<li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
							<i class="la la-users"></i>
							<span class="nav-text">Staff</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="all-staff.php">All Staff</a></li>
                            <li><a href="add-staff.php">Add Staff</a></li>
                            <li><a href="edit-staff.php">Edit Staff</a></li>
                            
                        </ul>
                    </li>
					<li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
							<i class="la la-gift"></i>
							<span class="nav-text">Holiday</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="all-holiday.php">All Holiday</a></li>
                            <li><a href="add-holiday.php">Add Holiday</a></li>
                            <li><a href="edit-holiday.php">Edit Holiday</a></li>
                            <li><a href="holiday-calendar.php">Holiday Calendar</a></li>
                        </ul>
                    </li>
				
				</ul>
            </div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
