<style>
  nav ul {
  list-style: none;
  margin: 0;
  padding: 0;
  background-color:#13274F;
}

nav ul li {
  display: inline-block;
  position: relative;
}

nav ul li a {
  display: block;
  padding: 1rem;
  color: white;
  text-decoration: none;
}

nav ul li:hover > a {
  background-color: #002244;
}

.dropdown-menu {
  display: none;
  position: absolute;
  top: 100%;
  left: 0;
  background-color: #13274F;
  margin: 0;
  padding: 0;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

.dropdown:hover .dropdown-menu {
  display: block;
}

  header h1 {
    margin: 0;
    padding-top: 20px;
    padding-bottom: 20px;
    text-align: left;  
    color:white;
  }
</style>

<header class="site-navbar site-navbar-target" role="banner">

<div class="container mb-3">
  <div class="d-flex align-items-center">
    <div class="site-logo mr-auto">
      <h1> MT/Ajmeer National School</h1>
    </div>
    <div class="site-quick-contact d-none d-lg-flex ml-auto ">
      <div class="d-flex site-info align-items-center mr-5">
        <span class="block-icon mr-3"><span class="icon-map-marker text-yellow"></span></span>
        <span>56 Main Street, Ukuwela, <br> Sri Lanka</span>
      </div>
      <div class="d-flex site-info align-items-center">
        <span class="block-icon mr-3"><span class="icon-clock-o"></span></span>
        <span>Monday - Friday 7:30 AM - 2:00 PM <br> Saturday and Sunday CLOSED</span>
      </div>
      
    </div>
  </div>
</div>

      <nav>
        <ul>
          <li><a href="welcome.php" >Home</a></li>
          <li><a href="about.php" >About</a></li>
          <li><a href="packages.php" >Packages</a></li>
          <li class="dropdown">
            <a href="#">Student</a>
            <ul class="dropdown-menu">
              <li><a href="registration.php">Student Registration</a></li>
              <li><a href="#">Student Details</a></li>
            </ul>
          </li>
          <li><a href="gallery.php" >Gallery</a></li>
          <li><a href="pricing.php" >Pricing</a></li>
          <li><a href="contact.php" >Contact</a></li>
        </ul>
      </nav>

</header>


